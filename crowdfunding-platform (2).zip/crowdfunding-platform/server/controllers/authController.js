import User from '../models/User.js';
import generateToken from '../utils/generateToken.js';

// @desc    Auth user/set token
// @route   POST /api/auth/login
// @access  Public
const authUser = async (req, res) => {
  const { email, password } = req.body;

  const user = await User.findOne({ email });

  if (user && (await user.matchPassword(password))) {
    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      token: generateToken(res, user._id),
    });
  } else {
    res.status(401);
    throw new Error('Invalid email or password');
  }
};

// @desc    Register a new user
// @route   POST /api/auth/register
// @access  Public
const registerUser = async (req, res) => {
  const { name, email, password, role } = req.body;

  const userExists = await User.findOne({ email });

  if (userExists) {
    res.status(400);
    throw new Error('User already exists');
  }

  const user = await User.create({
    name,
    email,
    password,
    role: role || 'investor',
  });

  if (user) {
    res.status(201).json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      token: generateToken(res, user._id),
    });
  } else {
    res.status(400);
    throw new Error('Invalid user data');
  }
};

// @desc    Get user profile
// @route   GET /api/auth/profile
// @access  Private
const getUserProfile = async (req, res) => {
  const user = await User.findById(req.user._id);

  if (user) {
    res.json({
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
    });
  } else {
    res.status(404);
    throw new Error('User not found');
  }
};

// @desc    Forgot password (Mock)
// @route   POST /api/auth/forgot-password
// @access  Public
const forgotPassword = async (req, res) => {
  const { email } = req.body;
  const normalizedEmail = email ? email.trim() : '';
  
  // Case-insensitive exact match
  const user = await User.findOne({ 
    email: { $regex: new RegExp(`^${normalizedEmail}$`, 'i') } 
  });

  if (user) {
    console.log(`[MOCK EMAIL] Password reset link sent to ${normalizedEmail}`);
    res.status(200).json({ message: 'Password reset link sent to your email' });
  } else {
    res.status(404);
    throw new Error('User not found');
  }
};

export { authUser, registerUser, getUserProfile, forgotPassword };
